package com.sunsoft.sprintproject.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunsoft.sprintproject.dao.ScreenDao;
import com.sunsoft.sprintproject.entity.Screen;
import com.sunsoft.sprintproject.entity.Show;
import com.sunsoft.sprintproject.repository.ShowRepository;



@Service
public class ScreenServiceImpl implements ScreenService {

	@Autowired
	ShowRepository showRepository;
	
	@Autowired
	ScreenDao screenDao;
	
	@Override
	public Show searchShow(String showName) {
		Optional<Show> showOptional = showRepository.findByName(showName);
		if(showOptional.isPresent()){
		List<Show> shows = screenDao.findShowByShowName(showOptional.get());
		if(shows.size()>0){
			return shows.get(0);
		}
		else
			return null;
		}
		else
			return null;
	}

	@Override
	public void addScreen(Screen screen) {
		screenDao.addScreen(screen);
		
	}

	@Override
	public List<Screen> showAllScreens() {
		return screenDao.showAllScreens();
	}

	@Override
	public void deleteScreen(int screenId) {
		// TODO Auto-generated method stub
		screenDao.deleteScreen(screenId);
	}

	

}