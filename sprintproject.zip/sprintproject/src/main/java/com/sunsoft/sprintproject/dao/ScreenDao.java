package com.sunsoft.sprintproject.dao;

import java.util.List;

import com.sunsoft.sprintproject.entity.Screen;
import com.sunsoft.sprintproject.entity.Show;

public interface ScreenDao {

	public List<Show> findShowByShowName(Show show);

	public void addScreen(Screen screen);

	public List<Screen> showAllScreens();

	public void deleteScreen(int screenId);

}
