package com.sunsoft.sprintproject.entity;

import java.io.Serializable;

public enum BookingStatus implements Serializable
{
		AVAILABLE, BOOKED, BLOCKED;

public String getStatus() {
    return this.name();
}
}