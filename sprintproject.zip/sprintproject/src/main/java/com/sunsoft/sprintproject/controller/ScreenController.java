package com.sunsoft.sprintproject.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.sunsoft.sprintproject.entity.Screen;
import com.sunsoft.sprintproject.entity.Show;
import com.sunsoft.sprintproject.repository.ScreenRepository;
import com.sunsoft.sprintproject.service.ScreenService;
import com.sunsoft.sprintproject.service.ScreenServiceImpl;




@RestController
@RequestMapping(value="/screen")
public class ScreenController {

	@Autowired
	ScreenService screenService;
	
	@GetMapping("/searchShow")
	public String searchShow(@RequestParam("showName") String showName){
		Show show = screenService.searchShow(showName);
		if(show != null){
			return show.getShowName()+"";
		}
		else
			return "No show present";
	}
	
	@GetMapping("/all")
	public List<Screen> showAllScreens()
	{
		return screenService.showAllScreens();
	}
	
	@PostMapping("/addScreen")
	public void addScreen(@RequestBody Screen screen)
	{
		screenService.addScreen(screen);
	}
	
	@DeleteMapping("{screenId}")
	public void deleteScreen(@PathVariable int screenId) {
		screenService.deleteScreen(screenId);

	}
}
