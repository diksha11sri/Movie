package com.sunsoft.sprintproject.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sunsoft.sprintproject.entity.Show;
import com.sunsoft.sprintproject.repository.ShowRepository;



@Component
public class ShowDaoImpl implements ShowDao{

	@Autowired
	ShowRepository showRepository;
	
	@Override
	public void addShow(Show show) {
		showRepository.save(show);		
	}
	@Override
	public List<Show> showAllSeats() {
		return (List<Show>) showRepository.findAll();
	}
	@Override
	public void deleteShow(int showId) {
      showRepository.deleteById(showId);		
	}
}
