package com.sunsoft.sprintproject.dao;

import java.util.List;

import com.sunsoft.sprintproject.entity.Show;

public interface ShowDao {


	void addShow(Show show);

	List<Show> showAllSeats();

	void deleteShow(int showId);
	
}