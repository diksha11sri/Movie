package com.sunsoft.sprintproject.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sunsoft.sprintproject.entity.Screen;
import com.sunsoft.sprintproject.entity.Show;

@Service
public interface ScreenService {

	public Show searchShow(String showName);

	public List<Screen> showAllScreens();

	public void addScreen(Screen screen);

	public void deleteScreen(int screenId);



}
