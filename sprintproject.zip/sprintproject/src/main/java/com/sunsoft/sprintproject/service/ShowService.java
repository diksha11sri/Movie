package com.sunsoft.sprintproject.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sunsoft.sprintproject.entity.Show;

@Service
public interface ShowService {


	public List<Show> showAllSeats();
	
	public void addShow(Show show);

	public void deleteShow(int showId);

}