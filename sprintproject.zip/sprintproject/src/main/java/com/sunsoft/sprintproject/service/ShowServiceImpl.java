package com.sunsoft.sprintproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunsoft.sprintproject.dao.ShowDao;
import com.sunsoft.sprintproject.entity.Show;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ShowServiceImpl implements ShowService {

	@Autowired
	ShowDao showDao;
	
	

	@Override
	public List<Show> showAllSeats() {
		return showDao.showAllSeats();
	}

	@Override
	public void addShow(Show show) {
		showDao.addShow(show);
		
	}

	@Override
	public void deleteShow(int showId) {
		showDao.deleteShow(showId);		
	}

	
}