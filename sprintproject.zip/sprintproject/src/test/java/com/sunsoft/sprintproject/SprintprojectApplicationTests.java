package com.sunsoft.sprintproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
